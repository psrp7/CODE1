﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace WebApplication1
{
    public partial class txtfileupload : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconn"].ToString());
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string Savepath = Server.MapPath("~/Uploaded/" + FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(Savepath);

                //string[] readtext = File.ReadAllLines(Savepath);
                var reader = new StreamReader(Savepath);
                var dt = new DataTable("tblaccount");
                dt.Columns.Add("SrNo", typeof(int));
                dt.Columns.Add("Branch", typeof(string));
                dt.Columns.Add("AccountType", typeof(string));
                dt.Columns.Add("Scheme", typeof(string));
                dt.Columns.Add("AccountNumber", typeof(string));
                dt.Columns.Add("CustomerNumber", typeof(string));
                dt.Columns.Add("NameOnCard", typeof(string));
                dt.Columns.Add("Limit", typeof(string));
                dt.Columns.Add("Address1", typeof(string));
                dt.Columns.Add("Address2", typeof(string));
                dt.Columns.Add("Address3", typeof(string));
                dt.Columns.Add("MothersName", typeof(string));
                dt.Columns.Add("Preference", typeof(string));
                dt.Columns.Add("Contact", typeof(string));
                dt.Columns.Add("PinCode", typeof(string));
                dt.Columns.Add("City", typeof(string));
                dt.Columns.Add("State", typeof(string));
                dt.Columns.Add("ProductCode", typeof(string));
                dt.Columns.Add("CardType", typeof(string));

                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine().Trim();
                    var values = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    string[] readtext = values;
                    var newRow = dt.NewRow();
                    int count = 1;
                    for (int i = 0; i < values.Length; i++)
                    {

                        if( count<=19)
                        {
                        
                         newRow[i] = readtext[i].Trim().ToString();
                         count++;
                        }
                        
                    }
                    dt.Rows.Add(newRow[0], newRow[1], newRow[2], newRow[3], newRow[4], newRow[5], newRow[6], newRow[7], newRow[8], newRow[9], newRow[10], newRow[11], newRow[12], newRow[13], newRow[14], newRow[15], newRow[16], newRow[17], newRow[18]);
                }
                   adddata(dt);
                   conn.Close();
            }
        }

        public void adddata(DataTable dt)   
        {
            try
            {
                conn.Open();
                
                cmd = new SqlCommand("sp_insertaccdetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@accounttype", dt);
                try
                {

               
                cmd.ExecuteNonQuery();
                dt.Clear();
                }
                catch (Exception ex)
                {

                }
                    

                }
            finally
            {
                cmd.Dispose();
            }
            } 


   
       
            
           
       
    }
}
