﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication1
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconn"].ToString());
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "alertuser", "alert('connected');", true);
            String Name = TextBox1.Text;
            String emailid = TextBox2.Text;
            String contact = TextBox3.Text;
            String password = TextBox4.Text;


            SqlCommand cmd = new SqlCommand("Inserteregistereddata", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", Name);
            cmd.Parameters.AddWithValue("@emailid", emailid);
            cmd.Parameters.AddWithValue("@contact", contact);
            cmd.Parameters.AddWithValue("@country", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@password", password);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

        }
    }
}