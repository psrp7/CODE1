﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class EMPDETAILS2 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconn"].ToString());

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                databind();
            }
            
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            
            foreach (GridViewRow GRD in GridView1.Rows)
            {
                GridViewRow row = GridView1.Rows[e.RowIndex];
                Label lblempid = (Label)GridView1.Rows[e.RowIndex].FindControl("lblempid");
                //int lblempid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
                string txtname = (row.FindControl("txtName") as TextBox).Text;
                string txtfathername = (row.FindControl("txtfathername") as TextBox).Text;
                string txtaddress = (row.FindControl("txtaddress") as TextBox).Text;
                string txtage = (row.FindControl("txtage") as TextBox).Text;
                string txtemail = (row.FindControl("txtemail") as TextBox).Text;
                string txtcontact = (row.FindControl("txtcontact") as TextBox).Text;
                //string txtname = (row.FindControl("txtName") as TextBox).Text;

                //Label lblempid = (Label)GridView1.Rows[e.RowIndex].FindControl("lblempid");
                //TextBox txtname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtname");
                //TextBox txtfathername = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfathername");
                //TextBox txtaddress = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtaddress");
                DropDownList rdgender = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("txtgender");
                //TextBox txtage = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtage");
                //TextBox txtemail = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtemail");
                //TextBox txtcontact = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtcontact");

                SqlCommand cmd = new SqlCommand("sp_updateempdetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", lblempid.Text);
                cmd.Parameters.AddWithValue("@name", txtname);
                cmd.Parameters.AddWithValue("@fathersname", txtfathername);
                cmd.Parameters.AddWithValue("@address", txtaddress);
                cmd.Parameters.AddWithValue("@gender", rdgender.SelectedValue);
                cmd.Parameters.AddWithValue("@age", txtage);
                cmd.Parameters.AddWithValue("@emailid", txtemail);
                cmd.Parameters.AddWithValue("@contact", txtcontact);
                //cmd.CommandText = "Update StudentRecord set Name='" + txtname.Text + "',ClassName='" + txtclassname.Text + "',RollNo='" + txtrollno.Text + "',EmailId='" + txtemailid.Text + "' where StId='" + lblstid.Text + "'"; 
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                GridView1.EditIndex = -1;
                databind();
                conn.Close();

            }

            //string address = (GridView1.FindControl("txtaddress") as TextBox).Text;


        }



        public void databind()
        {
            SqlCommand cmd = new SqlCommand("sp_bindempdatagridview", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TextBox myTextBox = (TextBox)(e.Row.Cells[1].FindControl("txtName"));
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            databind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            databind();
        }


    }
}
