﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;

    


namespace WebApplication1
{
    public partial class exlfileupload : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconn"].ToString());
        SqlCommand cmd;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();

        protected void Page_Load(object sender, EventArgs e)
        {
            Button2.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button2.Visible = true;
            string connectionString = "";
            if (FileUpload1.HasFile)
            {
                string savepath = Server.MapPath("~/Uploaded/") + FileUpload1.PostedFile.FileName;
                FileUpload1.SaveAs(savepath);
                string[] allowedfile = { ".xls", ".xlsx",".txt" };
                string fileextension = Path.GetExtension(FileUpload1.PostedFile.FileName);
                bool isValidFile = allowedfile.Contains(fileextension);

                    if (fileextension == ".xls")
                    {
                        connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + savepath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "alert('File Uploaded Successfully');", true);
                    }
                    else if (fileextension == ".xlsx")
                    {
                        connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + savepath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
                        //ScriptManager.RegisterStartupScript(this, this.GetType(), "alertUser", "alert('File Uploaded Successfully');", true);
                    }
                   

                    try
                    {
                        OleDbConnection econ = new OleDbConnection(connectionString);
                        OleDbCommand exlcmd = new OleDbCommand();
                        exlcmd.CommandType = System.Data.CommandType.Text;
                        exlcmd.Connection = econ;
                        OleDbDataAdapter da = new OleDbDataAdapter();
                        //DataTable dt = new DataTable();



                        econ.Open();
                        DataTable dtschema = econ.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        string SheetName = dtschema.Rows[0]["TABLE_NAME"].ToString();
                        exlcmd.CommandText = "select * from [" + SheetName + "]";
                        da.SelectCommand = exlcmd;
                        //da.Fill(ds);
                        da.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        insertdata(dt);
                        
                        //econ.Close();
                    }
                    catch(Exception ex)
                    {
                       
                    }
                    
                   
            }
        }

        public void getdata(DataTable dt)
        {
            

            conn.Open();
            cmd = new SqlCommand("sp_exportexcel", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            da.Fill(dt);

            cmd.ExecuteNonQuery();
         
            cmd.Dispose();

            
        }

        public void insertdata(DataTable dt)
        {
            conn.Open();
            cmd = new SqlCommand("sp_insertexlfile", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@exldetail", dt);

            cmd.ExecuteNonQuery();
            //ds.Clear();
           
            cmd.Dispose();
            
        }




        protected void Button2_Click(object sender, EventArgs e)
        {
            
            getdata(dt);
            
            string data = null;
            string FileName = "file";
            string path = @"D:\exported\";
            path = path + FileName;
            Microsoft.Office.Interop.Excel.Application excel;
            Microsoft.Office.Interop.Excel.Workbook excelworkBook;
            Microsoft.Office.Interop.Excel.Worksheet excelSheet;
            //object misValue = System.Reflection.Missing.Value;

            //Microsoft.Office.Interop.Excel.Range excelCellrange;

            excel = new Microsoft.Office.Interop.Excel.Application();
            excelworkBook = excel.Workbooks.Add();
            excelSheet = (Microsoft.Office.Interop.Excel.Worksheet)excelworkBook.Worksheets.get_Item(1);
            //excelSheet = (Microsoft.Office.Interop.Excel.Worksheet)excelworkBook.ActiveSheet;
            int i = 0;
            int j = 0;

            for (i = 0; i < dt.Columns.Count; i++)
            {
                excelSheet.Cells[1, i + 1] = dt.Columns[i].ColumnName;
            }

                for (i = 0; i < dt.Rows.Count ; i++)
                {
                    for (j = 0; j < dt.Columns.Count ; j++)
                    {
                        //GridView1cell cell = GridView1[j, i];
                        //excelsheet.Cells[i + 1, j + 1] = cell.Value;
                        data = dt.Rows[i].ItemArray[j].ToString();
                        excelSheet.Cells[i + 2, j + 1] = data;
                        // Cells[j, i] = dt.Rows[j][i]; 
                    }
                }
            excelworkBook.SaveAs(path, Excel.XlFileFormat.xlWorkbookNormal);
            excelworkBook.Close(true);
            excel.Quit();



            //excelCellrange = excelSheet.Range[excelSheet.Cells[1, 1], excelSheet.Cells[dt.Rows.Count, dt.Columns.Count]];
            //excelCellrange.EntireColumn.AutoFit();  

        }
    }
}