﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WebApplication1
{
    public partial class fileupload2 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconn"].ToString());
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string Savepath = Server.MapPath("~/Uploaded/" + FileUpload1.PostedFile.FileName);
                FileUpload1.SaveAs(Savepath);

                //string[] readtext = File.ReadAllLines(Savepath);
                var reader = new StreamReader(Savepath);
                //SqlDataAdapter da = new SqlDataAdapter();
                var dt = new DataTable("tblaccount");
                int count = 0;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine().Trim();
                    var values = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    string[] readtext = values;
                    while(count<readtext.Length)
                    {
                        dt.Columns.Add();
                        count++;
                    }
                    var newRow = dt.NewRow();
                    for (int i = 0; i < readtext.Length; i++)
                    {

                        newRow[i] = readtext[i].Trim().ToString();
                    }
                    dt.Rows.Add(newRow);
                }
                
                //da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                adddata(dt);
                conn.Close();
            }
        }

        public void adddata(DataTable dt)
        {
            try
            {
                conn.Open();

                cmd = new SqlCommand("sp_insertaccdetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@accounttype", dt);
                try
                {
                    cmd.ExecuteNonQuery();
                    dt.Clear();
                }
                catch (Exception ex)
                {

                }


            }
            finally
            {
                cmd.Dispose();
            }
        } 



    }
}