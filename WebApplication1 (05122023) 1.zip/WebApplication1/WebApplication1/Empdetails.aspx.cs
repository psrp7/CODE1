﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace WebApplication1
{
    public partial class Empdetails : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["sqlconn"].ToString());
        int Empid = 0;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Btn_update.Visible = false;
            databind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("sp_insertempdetails", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@fathersname", TextBox2.Text);
            cmd.Parameters.AddWithValue("@address", TextBox3.Text);
            cmd.Parameters.AddWithValue("@gender", RadioButtonList1.Text);
            cmd.Parameters.AddWithValue("@age", TextBox4.Text);
            cmd.Parameters.AddWithValue("@emailid", TextBox5.Text);
            cmd.Parameters.AddWithValue("@contact", TextBox6.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            databind();

            Clear();
        }

        public void databind()
        {
            SqlCommand cmd = new SqlCommand("sp_bindempdatagridview", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            int ProductID = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[2].Text.ToString());

            SqlCommand cmd = new SqlCommand("sp_deletefromgridview", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", ProductID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            databind();

        }
        
        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Btn_submit.Visible = false;
            Btn_update.Visible = true;
            int ProductID = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[2].Text.ToString());

            SqlCommand cmd = new SqlCommand("sp_getempldetails", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", ProductID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                TextBox1.Text = dt.Rows[0]["name"].ToString();
                TextBox2.Text = dt.Rows[0]["father_name"].ToString();
                TextBox3.Text = dt.Rows[0]["address"].ToString();
                RadioButtonList1.Text = dt.Rows[0]["gender"].ToString();
                TextBox4.Text = dt.Rows[0]["age"].ToString();
                TextBox5.Text = dt.Rows[0]["email_id"].ToString();
                TextBox6.Text = dt.Rows[0]["contact"].ToString();

                Session["Empid"] = dt.Rows[0]["empid"].ToString();

            }

             
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //int ProductID = Convert.ToInt32(GridView1.Rows[e.RowIndex].Cells[2].Text.ToString());
            Empid = Convert.ToInt32(Session["Empid"]);
            SqlCommand cmd = new SqlCommand("sp_updateempdetails", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Empid);
            cmd.Parameters.AddWithValue("@name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@fathersname", TextBox2.Text);
            cmd.Parameters.AddWithValue("@address", TextBox3.Text);
            cmd.Parameters.AddWithValue("@gender", RadioButtonList1.Text);
            cmd.Parameters.AddWithValue("@age", TextBox4.Text);
            cmd.Parameters.AddWithValue("@emailid", TextBox5.Text);
            cmd.Parameters.AddWithValue("@contact", TextBox6.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            databind();

            Clear();
            Btn_update.Visible = false;
            Btn_submit.Visible = true;
        }

        public void Clear()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            RadioButtonList1.ClearSelection();
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            Empid = 0;
        }



   
    }
}